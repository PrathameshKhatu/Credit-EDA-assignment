#!/usr/bin/env python
# coding: utf-8

# # Importing all required libraries
# 

# In[1]:


## Importing all the required libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
get_ipython().run_line_magic('matplotlib', 'inline')
import random
pd.set_option("max_rows", None)
pd.set_option('display.max_columns', 500)
import warnings
warnings.filterwarnings('ignore')


# In[3]:


#Importing datafiles
application_data = pd.read_csv('application_data.csv')
application_data.head(10)


# In[4]:


#datafile shape
application_data.shape


# In[5]:


#datafile description
application_data.describe()


# In[6]:


#loading the columns of datatype
application_data.info(verbose=True)


# ###  3) Missing and null values
# #### Due to huge size of data getting rid of columns having null values makes sense

# In[7]:


application_data.isnull().sum()


# #### Now we will find the percentage of missing values in each of the column

# In[8]:


count = application_data.isnull().sum()/len(application_data)*100
count


# In[9]:


len(count)


# #### Eliminating columns having more than 40% null values

# In[10]:


nullcount = count[count>=40]


# In[90]:


nullcount


# In[91]:


len(nullcount)


# #### There are 49 columns having null values more than or equal to 40

# #### Dropping columns having null values more than or equal to 40%

# In[92]:


columns_dropped = (count[count>=40].index)
columns_dropped = list(columns_dropped)
application_data.drop(labels=columns_dropped,axis=1,inplace=True)


# #### Identifying the shape of the modified data

# In[93]:


application_data.shape


# #### Finding percentage of null values after modification

# In[94]:


100*(application_data.isnull().sum()/len(application_data.index))


# #### Starting data handling analysis with imputing null values in AMT_ANNUITY Column

# ### AMT_ANNUITY Column

# In[95]:


application_data['AMT_ANNUITY'].describe()


# #### Counting null values in AMT_ANNUITY column

# In[96]:


application_data['AMT_ANNUITY'].isnull().sum()


# #### Percentage missing values

# In[97]:


float(100*(12/307511))


# ### AMT_ANNUITY

# In[98]:


application_data['AMT_ANNUITY'].describe()


# #### As maximum value is 258025.5 it is definietly an oulier hence we take median value to impute

# ### AMT_GOODS_PRICE column 

# In[99]:


# Total null values for AMT_GOODS_PRICE column
application_data.AMT_GOODS_PRICE.isnull().sum()


# In[100]:


#Findinng percentage missing values
float(278/307511*100)


# In[101]:


# Description of column
application_data['AMT_GOODS_PRICE'].describe()


# #### As column is numeric and has outlier we will substitute with median value

# ### For EXT_SOURCE_2

# In[102]:


#Total missing values in EXT_SOURCE_2
application_data.EXT_SOURCE_2.isnull().sum()


# In[103]:


# Finding % missing values in EXT_SOURCE_
float(660/307511*100)


# In[106]:


application_data['EXT_SOURCE_2'].describe()


# #### Here values of variables are vary close to 0 hence we will impute with 0.

# #### For NAME_TYPE_SUITE

# In[107]:


# Total missing values for NAME_TYPE_SUITE
application_data.NAME_TYPE_SUITE.isnull().sum()


# In[108]:


float(1292/307511*100)


# In[111]:


#identifying percentage for each entry
application_data.NAME_TYPE_SUITE.value_counts(normalize= True)


# In[110]:


#Finding MODE of NAME_TYPE_SUITE (most repetitive entry)
name_type_mode=application_data.NAME_TYPE_SUITE.mode()[0]
name_type_mode


# #### As the variable here is a categorical variable, we can impute the values here with the most repetitive entity i.e. 'Unaccompanied'

# #### For OCCUPATION_TYPE 

# In[112]:


application_data.OCCUPATION_TYPE.value_counts(normalize=True)


# In[113]:


#Finding MODE of OCCUPATION_TYPE (most repetitive entry)
occupation_mode=application_data.OCCUPATION_TYPE.mode()[0]
occupation_mode


# #### As the variable here is a categorical variable, we can impute the values here with the most repetitive entity i.e. 'Laborers'

# ### Checking and validating Datatypes

# In[114]:


#previewing the dataset
application_data.head()


# ##### Now we will check the unique values in the columns.
# 1) If the count of unique values <=40, it's a categorical column
# 
# 2) If the count of unique values > 50, it's a continuous column

# In[115]:


application_data.nunique().sort_values()


# #### Modifying data types of variables.

# #### DAYS_BIRTH variable

# In[118]:


application_data['DAYS_BIRTH'].describe()


# ##### *From above data we can see that the values of DAYS_BIRTH is negative and it makes sense to make it positive.*

# In[ ]:


application_data['DAYS_BIRTH']=abs(application_data['DAYS_BIRTH'])
application_data['DAYS_BIRTH'].describe()


# ##### DAYS_EMPLOYED variable

# In[119]:


application_data['DAYS_EMPLOYED']=abs(application_data['DAYS_EMPLOYED'])
application_data['DAYS_EMPLOYED'].describe()


# #### DAYS_EMPLOYED variable

# In[120]:


application_data['DAYS_EMPLOYED']=abs(application_data['DAYS_EMPLOYED'])
application_data['DAYS_EMPLOYED'].describe()


# #### DAYS_REGISTRATION variable

# In[121]:


application_data['DAYS_REGISTRATION']=abs(application_data['DAYS_REGISTRATION'])
application_data['DAYS_REGISTRATION'].describe()


# #### DAYS_ID_PUBLISH variable

# In[122]:


application_data['DAYS_ID_PUBLISH']=abs(application_data['DAYS_ID_PUBLISH'])
application_data['DAYS_ID_PUBLISH'].describe()


# #### Modifying data types other categorical variables

# In[123]:


application_data['REG_REGION_NOT_LIVE_REGION'] = application_data['REG_REGION_NOT_LIVE_REGION'].astype(object)
application_data['REG_REGION_NOT_WORK_REGION'] = application_data['REG_REGION_NOT_WORK_REGION'].astype(object)
application_data['LIVE_REGION_NOT_WORK_REGION'] = application_data['LIVE_REGION_NOT_WORK_REGION'].astype(object)
application_data['REG_CITY_NOT_LIVE_CITY'] = application_data['REG_CITY_NOT_LIVE_CITY'].astype(object)
application_data['REG_CITY_NOT_WORK_CITY'] = application_data['REG_CITY_NOT_WORK_CITY'].astype(object)
application_data['LIVE_CITY_NOT_WORK_CITY']=application_data['LIVE_CITY_NOT_WORK_CITY'].astype(object)
application_data.dtypes


# In[124]:


application_data.head()


# ## Handling Outliers in the data

# #### AMT_ANNUITY variable

# In[125]:


application_data.AMT_ANNUITY.describe()


# In[128]:


sns.boxplot(application_data.AMT_ANNUITY)
plt.title('Amount Annuity Distribution')
plt.show()


# #### From plot outlier is at 258025. Hence for imputing the outlier values, we will use median here.

# #### AMT_INCOME

# In[129]:


application_data.AMT_INCOME_TOTAL.describe()


# ##### Clearly we can see that there are outliers in AMT_INCOME_TOTAL

# In[130]:


plt.figure(figsize=(9,2))
sns.boxplot(application_data.AMT_INCOME_TOTAL)
plt.xscale('log')
plt.title('Income Distribution')
plt.show()


# In[13]:


application_data.AMT_INCOME_TOTAL.quantile([0.5,0.7,0.9,0.95,0.99,1])


# ##### The outlier in AMT_INCOME_TOTAL is standing at 1.17*10^8 and 99th percentile is at 472500 this confirms presence of outliers in the data. Hence,  we will cap the outliers.

# #### (VI.b) AMT_CREDIT

# In[134]:


application_data.AMT_CREDIT.describe()


# In[135]:


plt.figure(figsize=(9,2))
sns.boxplot(application_data.AMT_CREDIT)
plt.title('Credit Amount Distribution')
plt.show()


# In[15]:


application_data.AMT_CREDIT.quantile([0.5,0.7,0.9,0.95,0.99,1])


# ##### From above data we can see that ouliers are present in the data.

# #### (VI.(d)) DAYS_BIRTH 

# In[138]:


application_data.DAYS_BIRTH.describe()


# In[142]:


sns.boxplot(application_data.DAYS_BIRTH)
plt.title('AGE distribution in days')
plt.show()


# In[145]:


application_data.DAYS_BIRTH.quantile([0.5,0.7,0.9,0.95,0.99])


# ##### From boxplot and above data we can see that there are no otutliers in DAYS_BIRTH column. 

# ##### VI (e) DAYS_EMPLOYED 

# In[147]:


application_data.DAYS_EMPLOYED.describe()


# In[148]:


plt.figure(figsize=(15,5))
sns.boxplot(application_data.DAYS_EMPLOYED)
#plt.yscale('log')
plt.title('Distribution of Days the client employed')

plt.show()


# ##### As seen above, we have an outlier at 365243.

# #### (VII) BINNING VARIABLES

# #### (VII (a)) Credit amount

# In[149]:


bins = [0,350000,700000,1000000000]
slots = ['Low','Medium','High']

application_data['AMT_CREDIT_RANGE']=pd.cut(application_data['AMT_CREDIT'],bins=bins,labels=slots)


# #### (VII (b)) Income Amount

# In[150]:


bins = [0,200000,400000,10000000000]
slot = ['Low','Medium','High']
application_data['AMT_INCOME_RANGE']=pd.cut(application_data['AMT_INCOME_TOTAL'],bins,labels=slot)


# #### (VII (c)) DAYS BIRTH

# In[151]:


application_data['DAYS_BIRTH']= (application_data['DAYS_BIRTH']/365).astype(int)
application_data['DAYS_BIRTH_BINS']=pd.cut(application_data['DAYS_BIRTH'], bins=[19,25,35,60,100], labels=['Teen','Adult', 'Middle Age', 'Senior Citizen'])


# In[153]:


application_data.head()


# ### (VIII) ANALYSIS

# In[158]:


(application_data.TARGET.value_counts()/len(application_data))*100


# ##### From above data we get to know that there are 91.92% 0s and 8.073% 1s in TARGET variable. It means that 91.92% people make timely payment whie 8.073% people face dificulty in repayment.

# In[159]:


# Creating two datasets are of target=1(client with payment difficulties) and target=0(all other)
target1 = application_data[application_data['TARGET']==1]
target0 = application_data[application_data['TARGET']==0]


# In[160]:


# Checking TARGET 0 dataframe
target0.head()


# In[161]:


# Checking TARGET 1 dataframe
target1.head()


# #### (VIII (a)) Univariate Analysis

# ##### (VIII (a)) (i) Credit Amount Analysis

# In[162]:


#for payment difficulties
plt.figure(figsize = (20, 8))
plt.subplot(2, 2, 2)
plt.title('Credit amount of loan- Payment issues')
plt.ylim(0,100000)
sns.countplot(target1['AMT_CREDIT_RANGE'])
plt.show()


# In[163]:


# For non-payment difficulties
plt.figure(figsize = (20, 8))
plt.subplot(2, 2, 1)
plt.ylim(0,200000)
plt.title('Credit amount - No payment issues')
sns.countplot(target0['AMT_CREDIT_RANGE'])


# ##### From above plot we can say that customer with lower credit limit are more likely to payback a loan.

# ##### (VIII (a)) (i) Income analysis

# In[164]:


# For payment issues
plt.figure(figsize = (20, 8))
plt.subplot(2, 2, 2)
plt.title('Income - Payment issues')
plt.ylim(0,100000)
sns.countplot(target1['AMT_INCOME_RANGE'])
plt.show()


# In[165]:


# For non-payment issues
plt.figure(figsize = (20, 8))
plt.subplot(2, 2, 1)
plt.ylim(0,250000)
plt.title('Income - No payment issue')
sns.countplot(target0['AMT_INCOME_RANGE'])


# ##### When compared to other categories the clients who have lower income are more likely to payback a loan

# #### (VIII (b)) Univariate Analysis- Categorical Variables

# #### (VIII (b)) (i) Family Status

# In[169]:


# For no payment issues

plt.figure(figsize = (15,6))
plt.subplot(1, 2, 1)


sns.countplot(target0['NAME_FAMILY_STATUS'],color="blue")
plt.title('Family Status - No payment issues')
plt.ylim(0,300000)
plt.xticks(rotation = 45)

# For payment issues
plt.subplot(1, 2, 2)

sns.countplot(target1['NAME_FAMILY_STATUS'],color="red")
plt.title('Family Status - Payment issues')
plt.ylim(0,50000)
plt.xticks(rotation = 45)
plt.show()


# ##### Widowed are least likely to pay loan amounts and married people are most likely to repay loan amount.

# #### (VIII (b)) (ii) Education type analysis

# In[170]:


# For no payment issues

plt.figure(figsize = (15,6))
plt.subplot(1, 2, 1)


sns.countplot(target0['NAME_EDUCATION_TYPE'],color="blue")
plt.title('Education Type - No payment issues')
plt.ylim(0,250000)
plt.xticks(rotation = 45)

# For payment issues
plt.subplot(1, 2, 2)

sns.countplot(target1['NAME_EDUCATION_TYPE'],color="red")
plt.title('Education Type - Payment issues')
plt.ylim(0,50000)
plt.xticks(rotation = 45)
plt.show()


# ##### People having Secondary/Special Secondary education are the most likely to payback the loan. The people having an academic degree are most defaulters.

# ### (VIII (c)) Univariate Analysis- Continuous Variables

# #### (VIII (c)) (i) Annuity Amount

# In[172]:


sns.distplot(target0['AMT_ANNUITY'], hist = False, label="Success")
sns.distplot(target1['AMT_ANNUITY'], hist = False, label="Fail")
plt.title('Annuity Amount')
plt.grid(color='black', linestyle='-', linewidth=0.25, alpha=0.5) 
plt.show()


# #### (VIII (c)) (ii) Credit Amount

# In[173]:


sns.distplot(target0['AMT_CREDIT'], hist = False, label="Success")
sns.distplot(target1['AMT_CREDIT'], hist = False, label="Fail")
plt.title('AMT_CREDIT')
plt.grid(color='black', linestyle='-', linewidth=0.25, alpha=0.5) 
plt.show()


# ### (IX) Matrix Correlation

# In[174]:


#for all numerical columns
cor=target0.corr()
cor


# In[175]:


#elemination of repetitive correlation values
cor=cor.where(np.triu(np.ones(cor.shape), k=1).astype(np.bool))
cor


# In[176]:


#dataframe of correlation
cordf = cor.unstack().reset_index()
cordf.head()


# In[177]:


#Modifying column names
cordf.columns=['VAR1','VAR2','Correlation']
cordf.head()


# In[178]:


#eliminating columns with missing values
cordf.dropna(subset = ['Correlation'], inplace = True)
cordf.head()


# In[179]:


#Rounding off 
cordf['Correlation'] = round(cordf['Correlation'], 2)
cordf.head()


# In[180]:


#absolute value
cordf['Correlation'] = cordf['Correlation'].abs()
cordf.head()


# In[181]:


#Sorting correlation values
cordf.sort_values(by = 'Correlation', ascending = False).head(10)


# ##### From above table we can conclude that most correlated values are social circles for 30 and 60 days and the least correlated are the numbers and the age.

# In[182]:


#target1 dataframe
cor = target1.corr()

cor = cor.where(np.triu(np.ones(cor.shape), k=1).astype(np.bool))
cordf = cor.unstack().reset_index()
cordf.columns = ['VAR1', 'VAR2', 'Correlation']
cordf.dropna(subset = ['Correlation'], inplace = True)
cordf['Correlation'] = round(cordf['Correlation'], 2)
cordf.sort_values(by = 'Correlation', ascending = False).head(10)


# ### (X) Bivariate Analysis

# #### (X (a)) Numeric - Numeric

# #### Income vs Goods Price

# In[183]:


plt.figure(figsize = (15, 20))
plt.subplots_adjust(wspace=0.3)


plt.subplot(2,2,1)
sns.scatterplot(target0.AMT_INCOME_TOTAL,target0.AMT_GOODS_PRICE)
plt.xlabel('AMT_INCOME_TOTAL')
plt.ylabel('AMT_GOODS_PRICE')
plt.title('Income vs Goods Price - No Payment Issue')

plt.subplot(2,2,2)
sns.scatterplot(target1.AMT_INCOME_TOTAL,target1.AMT_GOODS_PRICE)
plt.xlabel('AMT_INCOME_TOTAL')
plt.ylabel('AMT_GOODS_PRICE')
plt.title('Income vs Goods Price - With Payment Issue')
plt.show()


# #### Goods Price vs Credit

# In[184]:


plt.figure(figsize = (15, 20))
plt.subplots_adjust(wspace=0.3)

plt.subplot(2,2,3)
sns.scatterplot(target0.AMT_GOODS_PRICE,target0.AMT_CREDIT)
plt.xlabel('AMT_GOODS_PRICE')
plt.ylabel('AMT_CREDIT')
plt.title('Goods Price vs Credit - No Payment Issue')
plt.xticks(rotation = 45)

plt.subplot(2,2,4)
sns.scatterplot(target1.AMT_GOODS_PRICE,target1.AMT_CREDIT)
plt.xlabel('AMT_GOODS_PRICE')
plt.ylabel('AMT_CREDIT')
plt.title('Goods Price vs Credit - With Payment Issue')
plt.xticks(rotation = 45)
plt.show()


# ##### From above graph we can say that clients who have repayed the loan on time have a higher chance of getting the loan again for more expensive goods and also have a high probable opportunity to get credit for particular goods value.

# #### (X (ii)) Numeric- Categorical

# #### Income range vs Educational Status

# In[185]:


plt.figure(figsize = (15, 8))
plt.subplot(1, 2, 1)
plt.title('Income Range & Education Status - No Payment Issue')

sns.countplot(x='AMT_INCOME_RANGE', hue='NAME_EDUCATION_TYPE', data=target0, palette='rocket')

# subplot 2
plt.subplot(1, 2, 2)
plt.title('Income Range & Education Status - With Payment Issue')

sns.countplot(x='AMT_INCOME_RANGE', hue='NAME_EDUCATION_TYPE', data=target1,palette='rocket')
plt.show()


# ##### People who are most likely to repay loan have Secondary/ Special Secondary education status and have lower income range

# #### Credit amount- Marital Status

# In[186]:


# Box plotting for Credit amount


plt.figure(figsize=(15,10))
plt.subplots_adjust(wspace=0.3)

plt.subplot(121)
sns.boxplot(data =target0, x='NAME_FAMILY_STATUS',y='AMT_CREDIT', hue ='NAME_EDUCATION_TYPE',orient='v]')
plt.title('Credit amount vs Marital Status - No Payment Issue')
plt.xticks(rotation=45)

plt.subplot(122)
sns.boxplot(data =target1, x='NAME_FAMILY_STATUS',y='AMT_CREDIT', hue ='NAME_EDUCATION_TYPE',orient='v]')
plt.title('Credit amount vs Marital Status - With Payment Issue')
plt.xticks(rotation=45)
plt.show()


# ##### Married people with higher education get higher credit compared to widows with lower education.

# ### (XI) Analysing previous loan applications.

# In[189]:


previous_application=pd.read_csv("previous_application.csv")
previous_application.head()


# In[191]:


#eliminating XNA and XAP
previous_application=previous_application.drop(previous_application[previous_application['NAME_CASH_LOAN_PURPOSE']=='XNA'].index)
previous_application=previous_application.drop(previous_application[previous_application['NAME_CASH_LOAN_PURPOSE']=='XAP'].index)


# In[192]:


#Merge the previous application & application data file
merged_data= pd.merge(application_data, previous_application, how='inner', on='SK_ID_CURR',suffixes='_x')
merged_data.head()


# In[196]:


#modification of columns names after merging

newdata = merged_data.rename({'NAME_CONTRACT_TYPE_' : 'NAME_CONTRACT_TYPE','AMT_CREDIT_':'AMT_CREDIT','AMT_ANNUITY_':'AMT_ANNUITY',
                         'WEEKDAY_APPR_PROCESS_START_' : 'WEEKDAY_APPR_PROCESS_START',
                         'HOUR_APPR_PROCESS_START_':'HOUR_APPR_PROCESS_START','NAME_CONTRACT_TYPEx':'NAME_CONTRACT_TYPE_PREV',
                         'AMT_CREDITx':'AMT_CREDIT_PREV','AMT_ANNUITYx':'AMT_ANNUITY_PREV',
                         'WEEKDAY_APPR_PROCESS_STARTx':'WEEKDAY_APPR_PROCESS_START_PREV',
                         'HOUR_APPR_PROCESS_STARTx':'HOUR_APPR_PROCESS_START_PREV'}, axis=1)
newdata.head()


# In[195]:


#eliminating Unwanted columns

newdata.drop(['SK_ID_CURR','WEEKDAY_APPR_PROCESS_START', 'HOUR_APPR_PROCESS_START','REG_REGION_NOT_LIVE_REGION', 
              'REG_REGION_NOT_WORK_REGION','LIVE_REGION_NOT_WORK_REGION', 'REG_CITY_NOT_LIVE_CITY',
              'REG_CITY_NOT_WORK_CITY', 'LIVE_CITY_NOT_WORK_CITY','WEEKDAY_APPR_PROCESS_START_PREV',
              'HOUR_APPR_PROCESS_START_PREV', 'FLAG_LAST_APPL_PER_CONTRACT','NFLAG_LAST_APPL_IN_DAY'],axis=1,inplace=True)
newdata.head()


# #### (XI (a)) Univariate Analysis

# In[197]:


# Distribution of contract status
sns.set_style('whitegrid')
sns.set_context('talk')

plt.figure(figsize=(20,20))
plt.rcParams["axes.labelsize"] = 20
plt.rcParams['axes.titlesize'] = 22
plt.rcParams['axes.titlepad'] = 30
plt.xticks(rotation=90)
plt.xscale('log')
plt.title('Distribution of purposes with target ')
ax = sns.countplot(data = newdata, y= 'NAME_CASH_LOAN_PURPOSE', order=newdata['NAME_CASH_LOAN_PURPOSE'].value_counts().index,hue = 'TARGET')


# ##### Clients who are taking a loan for 'Buying a garage' and for 'Money for a third person' are more likely to repay the loan hence should be prioritized.

# #### (XI (b)) Bivariate Analysis

# In[198]:


#Box plotting for Credit amount prev v/s Housing type

plt.figure(figsize=(20,10))
plt.xticks(rotation=45)
sns.barplot(data =newdata, y='AMT_CREDIT_PREV',hue='TARGET',x='NAME_HOUSING_TYPE',)
plt.title('Prev Credit amount vs Housing type')
plt.show()


# ##### For ease of payment "office apartment has higher credit compared to others. Bank should be cautious while lending money to co-op apartment type.

# ### Conclusion

# 1) Customers who have lower credit amount are more likely loyal i.e. they pay installments on time. Thus, banks should focus and lending small amount of money.
# 
# 2) Married clients are most likely to pay the loan on time as in general married people are more responsible. On other hand widowed clients are least likely to payback the reason could be financial unstability due to death of the partner. Thus, bank should target married customers. 
# 
# 3) People with high educational background i.e secondary/ special secondary are more likely to payback the loan compared to people with lower education. Thus, bank should target clients with higher education.
# 
# 4) From analysis of previous loan applications people who are taking loan for 'buying a garage' for 'lending a money to a third person' are more likely to payback a loan on time.
# 
# 

# 
